package pckg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public abstract class main implements Runnable{

	public static void main(String[] args) {
		
		
		
		
		
		
		
		
		
		
		

	}//end main
	
	
	

	private static File fichero() {
		File fichero = new File(".\\src\\files\\fichero.txt");
		
		if(fichero.exists()) System.out.println("El fichero ya est� creado");
		else
		{
			try {
				fichero.createNewFile();
				FileWriter fw = new FileWriter(fichero);
				PrintWriter pw= new PrintWriter(fw);
				pw.write("#Fichero de configuraci�n echo.props"+"\n"+ "puerto=2222"+"\n");
				fw.close();
				pw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero");
		}//end else
		
		return fichero;
		
	}//end fichero 




	
	public void run(char vocal, String classpath, File fichero) {
		
		String filename = fichero.getName();
		String fileresult = "num" + vocal +".txt";
		fichero = fichero();
		FilesManagedment fm = new FilesManagedment();
		ProcessBuilder pb = new ProcessBuilder("java","-cp", classpath,filename, fileresult);
		
		
		
	}




	

}
