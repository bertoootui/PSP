package pckg;

import java.io.File;

import java.io.IOException;

public class FilesManagedment {

	
	public static void main(String[] args) {
		
		String filename = args[0];
		char vocal =  args[1].charAt(0);
		String fileResult = args[2];
		
		if(counter(filename, vocal, fileResult))
		{
			System.out.println("Se ha conseguido volcar el conteo");
		}
		else
		{
			System.out.println("No se ha podido volcar el conteo");
		}
		
		
		
	
		
		
		
		
		
		
		
		
		
	}//end main
	
	
	
	
	
	public static boolean counter (String fileName, char vocal, String fileResult)
	{
		File fichero = new File(fileName);
		File resultado = new File(fileResult);
		FilesProperties fp = new FilesProperties();
		
		int numvocal = 0;
		char vocales;
		
		boolean contador = false;
		
		if(fichero.exists()) 
		{
			try {
				while(fp.getBufferedReader(fichero).read()!=-1)
				{
					String linea = fp.getBufferedReader(fichero).readLine();
					for(int i= 0; i<linea.length();i++) 
					{
						vocales = linea.charAt(i);
						if(vocales == vocal) numvocal++;
						
						
					}//end for
					
				}//end while
				
				fp.getPrintWriter(resultado).write(numvocal);
				
				contador = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}//end if

		else
		{
			contador = false;
			
		}//end else
		
		
		
		
		
		
		
		
		
		
		return contador;
	}
	
	
}
