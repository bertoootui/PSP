package pckg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FilesProperties {
		
	public BufferedReader getBufferedReader(File fichero) {
		BufferedReader br = null;
		try {
			FileReader fr = new FileReader(fichero);
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return br;
		
	}//end getBufferedReader
	
	public PrintWriter getPrintWriter(File fichero)
	{
		PrintWriter pw = null;
		try {
			FileWriter fw = new FileWriter(fichero);
			pw = new PrintWriter(fw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pw;
		
	}//end getPrintWriter
	
}//end class
